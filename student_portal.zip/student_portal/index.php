<?php
require "functions.php";
$uri = $_SERVER['REQUEST_URI'];

if ($uri === "/") {
    require "controllers/index.php";
} else if ($uri === "/attendance") {
    require "controllers/attendance.php";
} else if ($uri === "/forgot-password") {
    require "controllers/forgot-password.php";
} else if ($uri === "/semester-result") {
    require "controllers/semester-result.php";
} else if ($uri === "/exam-schedule") {
    require "controllers/exam-schedule.php";
} else if ($uri === "/admin-login") {
    require "controllers/admin-login.php";
} else if ($uri === "/student-login") {
    require "controllers/student-login.php";
} else if ($uri === "/student-registration") {
    require "controllers/student-registration.php";
} else if ($uri === "/successful-registration") {
    require "controllers/succesful-registration.php";
} else if ($uri === "/profile") {
    require "controllers/profile.php";
} else {
    http_response_code(404);
    echo "<h1>404 Not Found</h1>";
}
