<?php

$title = "Test Schedule";
require "views/test-schedule.view.php";
