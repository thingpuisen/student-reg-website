<?php

$title = "Student Registration";
require "views/student-registration.view.php";
