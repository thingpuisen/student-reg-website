<?php

$title = "Student Login";
require "views/student-login.view.php";
