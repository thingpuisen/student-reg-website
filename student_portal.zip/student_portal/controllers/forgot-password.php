<?php

$title = "Reset Password";
require "views/forgot-password.view.php";
