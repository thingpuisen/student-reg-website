<?php

$title = "Semester Results";
require "views/semester-result.view.php";
