<?php
$title = "Successful Registration";
require "views/index.successful-registration.view.php";
