<?php

function dd($value)
{
    echo "<pre>";
    var_dump($value);
    echo "</pre>";

    die();
}


function isUrl($value)
{
    $_SERVER['REQUEST_URI'] === $value;
}
