<header class="container">

    <h1 style="text-align: center;">Mizoram University Student Portal</h1>

    </style>
</header>

<nav class="container">
    <ul>

        <li><a href="/">Profile</a></li>
        <li><a href="/attendance">Attendance</a></li>
        <li><a href="/semester-result">Semester Results</a></li>
        <li><a href="/test-schedule">Test Schedule</a></li>
        <li><a href="/exam-schedule">Exam schedule</a></li>

    </ul>
    <ul>
        <li><a href="/student-login">Logout</a></li>
    </ul>
</nav>