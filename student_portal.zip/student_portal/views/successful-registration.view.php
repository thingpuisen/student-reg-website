<?php
require "views/partials/head.php";
?>

<main class="container">
    <h1 style="text-align: center;">Registration Successful</h1>
    <p style="text-align: center;">Your registration was successful! You can now log in to your account.</p>
    <div class="form-footer">
        <p><a href="/student-login">Login here</a></p>
        <p><a href="/admin-login">Login as admin</a></p>
    </div>