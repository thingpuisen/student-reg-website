<?php
require "partials/head.php";
require "partials/nav.php"; ?>

<main class="container">
    <h2>Test Schedule</h2>

    <table role="grid">
        <thead>
            <tr>
                <th>Subject</th>
                <th>Date</th>

            </tr>
        </thead>
        <tbody>
            <tr>
                <td>Mathematics III</td>
                <td>2025-05-10</td>

            </tr>
            <tr>
                <td>Data Structures</td>
                <td>2025-05-12</td>

            </tr>
            <tr>
    </table>
</main>
</body>

</html>