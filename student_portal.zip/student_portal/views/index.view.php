<?php

require "partials/head.php";
require "partials/nav.php";
?>

<main class="container">
    <h2>Student Profile</h2>
    <article>
        <p><strong>Name:</strong> John Doe</p>
        <p><strong>Date of Birth:</strong> 2002-06-15</p>
        <p><strong>MZU ID:</strong> MZU123456</p>
        <p><strong>Department:</strong> Computer Engineering</p>
        <p><strong>Semester:</strong> 5th Semester</p>
        <p><strong>Contact:</strong> 9876543210</p>
        <p><strong>Password:</strong> ********</p>
    </article>

</main>


</body>

</html>